#!/bin/bash
export OPENSSL_armcap=0
./server/mcpeserver -dg ~/.local/share/mcpelauncher/ -dd ./server/server-data -mz
