#! /bin/bash
./server/Sakura_frpc_linux_arm --su=账号 --sp=密码 --sid=10
