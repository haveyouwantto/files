./server/mcpelauncher-extract ./Minecraft.apk ~/.local/share/mcpelauncher/
